#include <stdio.h>

int main(void)
{
	int i, j;
	for(;;) {
	for (i = 0; i < 1000000; i++) {
		for (j = 0; j < 50000; j++) {
			;
		}
	}
	}
}


			
